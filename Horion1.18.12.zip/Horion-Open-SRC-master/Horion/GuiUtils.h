#pragma once
#include "DrawUtils.h"

class GuiUtils {
public:
	static void drawCrossLine(vec2_t pos, MC_Color col, float lineWidth, float crossSize, bool secondCross);
};
