#pragma once

#include "../ScriptManager.h"

class HorionFunctions {
public:
	DECL_FUN(getCommandManager);
	DECL_FUN(getModuleManager);
	DECL_FUN(getDrawUtils);
};
